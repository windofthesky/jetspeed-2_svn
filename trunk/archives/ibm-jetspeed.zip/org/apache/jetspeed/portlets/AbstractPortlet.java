package org.apache.jetspeed.portlets;

//jetspeed
import org.apache.jetspeed.portlet.*;

//java stuff
import java.io.IOException;


public abstract class AbstractPortlet extends PortletAdapter
{

    public PortletConfig getConfig() {
        return getPortletConfig();
    }

}
