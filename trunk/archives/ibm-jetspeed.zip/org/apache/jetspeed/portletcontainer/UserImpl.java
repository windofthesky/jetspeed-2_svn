package org.apache.jetspeed.portletcontainer;

// jetspeed
import org.apache.jetspeed.portlet.*;
import org.apache.jetspeed.portletcontainer.information.*;

// java
import java.util.Enumeration;

public class UserImpl implements User,
                                 java.io.Serializable
{
    private UserInformation user = null;

    public UserImpl(UserInformation user)
    {
        this.user = user;
    }
    
    public String getID ()
    {
        return user.getID();
    }

    public String getUserID ()
    {
        return user.getUserID();
    }

    public String getGivenName ()
    {
        return user.getGivenName();
    }

    public String getFullName ()
    {
        return user.getFullName();
    }

    public String getFamilyName ()
    {
        return user.getFamilyName();
    }

    public String getNickName ()
    {
        return user.getNickName();
    }

    public long getLastLoginTime ()
    {
        return user.getLastLoginTime();
    }

    public Object getAttribute(String name)
    {
        return user.getAttribute(name);
    }

    public Enumeration getAttributeNames()
    {
        return user.getAttributeNames();
    }

}
