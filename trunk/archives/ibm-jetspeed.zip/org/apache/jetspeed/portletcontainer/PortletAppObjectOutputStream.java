package org.apache.jetspeed.portletcontainer;


import java.io.ObjectStreamClass;
import java.io.IOException;

public class PortletAppObjectOutputStream extends java.io.ObjectOutputStream {
    private ClassLoader classloader_ = null;

    protected PortletAppObjectOutputStream() throws java.io.IOException, SecurityException {
        super();
    }

    public PortletAppObjectOutputStream(java.io.OutputStream out) throws java.io.IOException, java.io.StreamCorruptedException {
        super(out);
    }
    
    protected Class resolveClass(ObjectStreamClass v)
    throws IOException, ClassNotFoundException
    {
        return classloader_.loadClass(v.getName());
    }

    public void setClassLoader(ClassLoader classloader) {
        classloader_ = classloader;
    }
}
