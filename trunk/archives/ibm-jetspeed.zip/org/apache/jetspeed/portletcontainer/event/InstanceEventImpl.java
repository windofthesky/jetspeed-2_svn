package org.apache.jetspeed.portletcontainer.event;

import org.apache.jetspeed.portlet.*;
import org.apache.jetspeed.portlet.event.*;

import org.apache.jetspeed.portletcontainer.om.portletinstanceregistry.PortletInstanceEntry;

public abstract class InstanceEventImpl extends EventImpl
{
    private PortletInstanceEntry entry = null;

    public InstanceEventImpl(PortletInstanceEntry entry,
                             PortletRequest request)
    {
        super (request);

        this.entry = entry;
    }

    // additional methods

    public PortletInstanceEntry getPortletInstanceEntry()
    {
        return entry;
    }

}