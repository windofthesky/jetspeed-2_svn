package org.apache.jetspeed.portletcontainer.event;

import org.apache.jetspeed.portlet.*;
import org.apache.jetspeed.portlet.event.*;

import org.apache.jetspeed.portletcontainer.invoker.*;

public abstract class EventImpl implements Event
{
    private Portlet portlet = null;
    private PortletRequest request = null;

    public EventImpl(PortletRequest request)
    {
        this.request = request;
    }

    public PortletRequest getRequest ()
    {
        return request;
    }

    public Portlet getPortlet ()
    {
        return portlet;
    }

    // additional methods

    public void setPortlet(Portlet portlet)
    {
        this.portlet = portlet;
    }

    abstract public void prepare(EventEnvironment evtEnv) throws PortletException, PortletInvokerException;

}