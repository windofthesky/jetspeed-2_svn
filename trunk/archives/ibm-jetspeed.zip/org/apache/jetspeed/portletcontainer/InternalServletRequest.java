package org.apache.jetspeed.portletcontainer;


// java
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.InputStream;
import java.io.IOException;
import java.util.*;

public class InternalServletRequest implements HttpServletRequest
{
    private HttpSession _session = null;
    private HashMap attributes = new HashMap();

    public InternalServletRequest(HttpSession aSession)
    {
        _session = aSession;
    }

    public HttpSession getSession(boolean create)
    {
        return _session;
    }

    public HttpSession getSession()
    {
        return _session;
    }

    public void removeAttribute(java.lang.String s)
    {
        attributes.remove(s);
    }

    public java.lang.Object getAttribute(java.lang.String name)
    {
        return attributes.get(name);
    }

    public java.util.Enumeration getAttributeNames()
    {
        Vector keys = new Vector(attributes.keySet());
        return keys.elements();
    }

    public void setAttribute(java.lang.String key,
                             java.lang.Object value)
    {
        attributes.put(key, value);
    }

    // dummy methods

    public java.lang.String getAuthType()
    {
        return null;
    }

    public Cookie[] getCookies()
    {
        return new Cookie[0];
    }

    public long getDateHeader(java.lang.String name)
    {
        return -1;
    }

    public java.lang.String getHeader(java.lang.String name)
    {
        return null;
    }


    public java.util.Enumeration getHeaderNames()
    {
        return new Vector().elements();
    }

    public int getIntHeader(java.lang.String name)
    {
        return -1;
    }

    public java.lang.String getMethod()
    {
        return "GET";
    }

    public java.lang.String getPathInfo()
    {
        return null;
    }

    public java.lang.String getPathTranslated()
    {
        return null;
    }

    public java.lang.String getQueryString()
    {
        return null;
    }

    public java.lang.String getRemoteUser()
    {
        return null;
    }

    public java.lang.String getRequestedSessionId()
    {
        return null;
    }

    public java.lang.String getRequestURI()
    {
        return "";
    }

    public java.lang.String getServletPath()
    {
        return "";
    }

    public java.util.Enumeration getLocales()
    {
        return new Vector().elements();
    }

    public java.util.Locale getLocale()
    {
        return null;
    }

    public String getContextPath()
    {
        return "";
    }

    public java.security.Principal getUserPrincipal()
    {
        return null;
    }

    public boolean isSecure()
    {
        return false;
    }

    public java.util.Enumeration getHeaders(java.lang.String s)
    {
        return new Vector().elements();
    }

    public javax.servlet.RequestDispatcher getRequestDispatcher(java.lang.String s)
    {
        return null;
    }

    public boolean isUserInRole(java.lang.String s)
    {
        return false;
    }

    public boolean isRequestedSessionIdValid()
    {
        return true;
    }

    public boolean isRequestedSessionIdFromCookie()
    {
        return false;
    }

    public boolean isRequestedSessionIdFromURL()
    {
        return false;
    }

    public boolean isRequestedSessionIdFromUrl()
    {
        return false;
    }

    public java.lang.String getCharacterEncoding()
    {
        return null;
    }

    public int getContentLength()
    {
        return -1;
    }

    public java.lang.String getContentType()
    {
        return null;
    }

    public ServletInputStream getInputStream() throws java.io.IOException {
        throw new java.io.IOException();
    }

    public java.lang.String getParameter(java.lang.String name)
    {
        return null;
    }

    public java.util.Enumeration getParameterNames()
    {
        return new Vector().elements();
    }

    public java.lang.String[] getParameterValues(java.lang.String name)
    {
        return new String[0];
    }

    public java.lang.String getProtocol()
    {
        return "http/1.1";
    }

    public java.lang.String getScheme()
    {
        return "http";
    }

    public java.lang.String getServerName()
    {
        return "";
    }

    public int getServerPort()
    {
        return 80;
    }

    public java.io.BufferedReader getReader() throws java.io.IOException {
        throw new java.io.IOException();
    }

    public java.lang.String getRemoteAddr()
    {
        return "";
    }

    public java.lang.String getRemoteHost()
    {
        return "";
    }

    public java.lang.String getRealPath(java.lang.String path)
    {
        return path;
    }
}
