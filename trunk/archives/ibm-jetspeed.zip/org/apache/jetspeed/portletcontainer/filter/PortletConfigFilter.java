package org.apache.jetspeed.portletcontainer.filter;

import org.apache.jetspeed.portlet.*;

import org.apache.jetspeed.portletcontainer.*;

// java
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class PortletConfigFilter
{
    private ServletConfig servletConfig = null;
    private PortletConfig portletConfig = null;
    
    public PortletConfigFilter(ServletConfig servletConfig,
                               PortletConfig portletConfig)
    {
        this.servletConfig = servletConfig;
        this.portletConfig = portletConfig;
    }

    public void setServletConfig(ServletConfig servletConfig)
    {
        this.servletConfig = servletConfig;
    }

    public String getInitParameter(String name)
    {
        return servletConfig.getInitParameter(name);
    }

    public Enumeration getInitParameterNames()
    {
        return servletConfig.getInitParameterNames();
    }

    public String getServletName()
    {
        return servletConfig.getServletName();
    }

}
