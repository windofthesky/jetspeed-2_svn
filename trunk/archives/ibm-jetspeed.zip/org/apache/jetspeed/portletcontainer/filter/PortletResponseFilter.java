package org.apache.jetspeed.portletcontainer.filter;

import org.apache.jetspeed.portlet.*;

import org.apache.jetspeed.portletcontainer.*;

// java
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;
import java.io.*;

public class PortletResponseFilter
{
    private HttpServletResponse servletResponse = null;
    private PortletResponse portletResponse = null;
    
    public PortletResponseFilter(HttpServletResponse servletResponse,
                                PortletResponse portletResponse)
    {
        this.servletResponse = servletResponse;
        this.portletResponse = portletResponse;
    }

    public void setServletResponse(HttpServletResponse servletResponse)
    {
        this.servletResponse = servletResponse;
    }

    public String encodeRedirectURL(String url)
    {
        return url;
    }

    public void sendRedirect(String location) throws IOException
    {
    }

    public void sendError(int sc, String msg) throws IOException
    {
    }

    public void sendError(int sc) throws IOException
    {
    }

    public void setContentLength(int len)
    {

    }

    public ServletOutputStream getOutputStream() throws IOException
    {
        throw new IllegalStateException();
    }

    public void setBufferSize(int size)
    {
        throw new IllegalStateException();
    }

    public void flushBuffer() throws IOException
    {
        servletResponse.flushBuffer();
    }

    public void setContentType(String type)
    {
        // do nothing. this is handled by the Portal itself
    }

    public void reset()
    {
        throw new IllegalStateException();
    }

    public int getBufferSize()
    {
        return 0;
    }

    public Locale getLocale()
    {
        return servletResponse.getLocale();
    }

    public boolean isCommitted()
    {
        return true;
    }

    public void setLocale(Locale loc)
    {
        // do nothing. this is handled by the Portal itself
    }

}
