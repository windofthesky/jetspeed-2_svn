package org.apache.jetspeed.portlet.spi;
    
public class Constants {

    public final static String METHOD_ID
        = "org.apache.jetspeed.portlet.Portlet.METHOD_ID";
    public final static String PARAM_INTERCEPTOR                        
        = "org.apache.jetspeed.portlet.Portlet.INTERCEPTOR";
    public final static String PARAM_PORTLETREQUEST                     
        = "org.apache.jetspeed.portlet.Portlet.PORTLETREQUEST";
    public final static String PARAM_PORTLETRESPONSE                    
        = "org.apache.jetspeed.portlet.Portlet.PORTLETRESPONSE";
    public final static String PARAM_PORTLETCONFIG                      
        = "org.apache.jetspeed.portlet.Portlet.PORTLETCONFIG";
    public final static String PARAM_PORTLETSETTINGS                    
        = "org.apache.jetspeed.portlet.Portlet.PORTLETSETTINGS";
    public final static String PARAM_PORTLETSESSION                     
        = "org.apache.jetspeed.portlet.Portlet.PORTLETSESSION";
    public final static String PARAM_STATICTITLE                        
        = "org.apache.jetspeed.portlet.Portlet.STATICTITLE";

    public final static int METHOD_INCLUDE_PORTLET_TITLE                = 100;

    public final static int METHOD_PORTLET_LOGIN                        = 115;

    public final static int METHOD_PORTLET_BEGINPAGE                    = 118;

    public final static int METHOD_PORTLET_SERVICE                      = 120;

    public final static int METHOD_PORTLET_ENDPAGE                      = 122;

    public final static int METHOD_PORTLET_LOGOUT                       = 125;

    public final static int METHOD_PORTLET_DESTROY_CONCRETE             = 127;

    public final static int METHOD_PORTLET_DESTROY                      = 130;

    // all events have to be in the range of 200 to 300
    public final static int METHOD_PERFORM_ACTION                       = 200;
    public final static String PARAM_ACTION_EVENT                       
        = "org.apache.jetspeed.portlet.Portlet.ActionEvent";
    public final static int METHOD_PERFORM_MESSAGE                      = 202;
    public final static String PARAM_MESSAGE_EVENT                      
        = "org.apache.jetspeed.portlet.Portlet.MessageEvent";
    public final static int METHOD_PERFORM_WINDOW                       = 204;
    public final static String PARAM_WINDOW_EVENT                       
        = "org.apache.jetspeed.portlet.Portlet.WindowEvent";

    public final static int METHOD_PORTLET_SETTINGS_EVENT               = 206;
    public final static int METHOD_PORTLETAPPLICATION_SETTINGS_EVENT    = 208;
    public final static String PARAM_SETTINGS_EVENT
        = "com.ibm.wps.portletcontainer.invoker.settings";

}
