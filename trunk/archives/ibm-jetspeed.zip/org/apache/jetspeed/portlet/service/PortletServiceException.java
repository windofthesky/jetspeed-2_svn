package org.apache.jetspeed.portlet.service;

import org.apache.jetspeed.portlet.*;

/**
 * The base class of all checked exceptions thrown by portlet services.
 *
 * @author <A HREF="mailto:stephan.hesmer@de.ibm.com">Stephan Hesmer</A>
 */
public class PortletServiceException extends PortletException {

    /**
     ** Constructs a new portlet exception.
     **/

    public PortletServiceException ()
    {
        super ();
    }

    /**
    * Creates a new exception with the sepcified detail message.
    *
    * @param message A string indicating why this exception is thrown.
    */
    public PortletServiceException(String message) {
	super(message);
    }
}
