package org.apache.jetspeed.portlet.service;

/**
 ** The <CODE>PortletServiceNotFoundException</CODE> is thrown if 
 ** a portlet attempts to access an service that is not found.
 **
 ** @see   org.apache.jetspeed.portlet.PortletContext
 **
 ** @author <A HREF="mailto:stephan.hesmer@de.ibm.com">Stephan Hesmer</A>
 **/

public class PortletServiceNotFoundException extends PortletServiceException
{
    public PortletServiceNotFoundException ()
    {
    }
}
