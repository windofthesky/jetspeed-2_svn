package org.apache.jetspeed.portlet.service;

/**
 * The <CODE>PortletService</CODE> interface is the base for all
 * portlet services.
 * 
 * Portlets can obtain portlet service instances by calling the
 * method <code>PortletContext.getService</code>.
 *
 * @see   org.apache.jetspeed.portlet.PortletContext
 *
 * @author <A HREF="mailto:stephan.hesmer@de.ibm.com">Stephan Hesmer</A>
 */
public interface PortletService
{

}
