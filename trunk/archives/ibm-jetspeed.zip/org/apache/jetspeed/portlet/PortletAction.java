package org.apache.jetspeed.portlet;

/**
 ** The <CODE>PortletAction</CODE> can be implemented to define
 ** portlet-specific actions that need to be executed for specific
 ** URIs.
 **
 ** <P>
 ** A portlet action can carry any information. It should however not
 ** store a request, response, or session object. This information is
 ** part of the action event that will be sent to the registered
 ** action listener(s).
 **
 ** @see   PortletURI
 ** @see   org.apache.jetspeed.portlet.event.ActionEvent
 **
 ** @author   <A HREF="mailto:tboehme@apache.org">Thomas F. Boehme</A>
 **/

public interface PortletAction extends java.io.Serializable
{
}
