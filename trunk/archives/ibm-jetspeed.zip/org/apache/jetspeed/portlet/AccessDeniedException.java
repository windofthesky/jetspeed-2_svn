package org.apache.jetspeed.portlet;

/**
 ** The <CODE>AccessDeniedException</CODE> is thrown if a portlet
 ** attempts to access dynamic data in a manner that it is not
 ** allowed to. For example, a portlet which is not in CONFIGURE
 ** mode cannot set or remove attributes in the dynamic data of
 ** the portlet configuration. However, it can read attributes.
 ** This exception is also thrown if a portlet tries to access
 ** an event based function but is not during the event processing.
 **
 ** @see   PortletConfig
 ** @see   PortletData
 ** @see   PortletRequest
 ** @see   PortletContext
 **
 ** @author   <A HREF="mailto:tboehme@apache.org">Thomas F. Boehme</A>
 **/

public class AccessDeniedException extends PortletException
{
    public AccessDeniedException ()
    {
    }
}
