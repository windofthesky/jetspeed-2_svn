
dojo.provide("dojo.widget.validate");
dojo.deprecated("dojo.widget.validate",
"use one of the specific widgets in dojo.widget.<name>Textbox instead", "0.5");
