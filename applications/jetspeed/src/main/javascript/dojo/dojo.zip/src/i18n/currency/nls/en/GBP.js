
({"displayName":"British Pound Sterling","symbol":"£"})