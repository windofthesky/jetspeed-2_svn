
({"rangeMessage":"* Cette valeur est hors limites.","invalidMessage":"* La valeur saisie est incorrecte.","missingMessage":"* Cette valeur est obligatoire."})