
dojo.provide("dojo.graphics.*");
