
({"displayName":"ITL","symbol":"₤"})