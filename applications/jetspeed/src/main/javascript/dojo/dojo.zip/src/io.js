
dojo.provide("dojo.io");
dojo.require("dojo.io.*");
dojo.deprecated("dojo.io", "replaced by dojo.io.*", "0.5");
