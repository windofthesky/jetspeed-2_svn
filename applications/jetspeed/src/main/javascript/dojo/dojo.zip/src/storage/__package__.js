
dojo.kwCompoundRequire({common: ["dojo.storage"],
browser: ["dojo.storage.browser"]});
dojo.provide("dojo.storage.*");
