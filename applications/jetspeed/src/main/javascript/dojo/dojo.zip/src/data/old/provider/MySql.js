
dojo.provide("dojo.data.old.provider.MySql");
dojo.require("dojo.data.old.provider.Base");
dojo.data.old.provider.MySql = function() {dojo.unimplemented('dojo.data.old.provider.MySql');};
dojo.inherits(dojo.data.old.provider.MySql, dojo.data.old.provider.Base);
