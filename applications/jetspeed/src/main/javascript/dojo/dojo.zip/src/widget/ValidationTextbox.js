
dojo.provide("dojo.widget.ValidationTextbox");
dojo.require("dojo.widget.Textbox");
dojo.require("dojo.i18n.common");
dojo.widget.defineWidget(
"dojo.widget.ValidationTextbox",
dojo.widget.Textbox,
function() {this.flags = {};},
{required: false,
rangeClass: "range",
invalidClass: "invalid",
missingClass: "missing",
classPrefix: "dojoValidate",
size: "",
maxlength: "",
promptMessage: "",
invalidMessage: "",
missingMessage: "",
rangeMessage: "",
listenOnKeyPress: true,
htmlfloat: "none",
lastCheckedValue: null,
templatePath: dojo.uri.dojoUri("src/widget/templates/ValidationTextbox.html"),
templateCssPath: dojo.uri.dojoUri("src/widget/templates/Validate.css"),
invalidSpan: null,
missingSpan: null,
rangeSpan: null,
getValue: function() {return this.textbox.value;},
setValue: function(value) {this.textbox.value = value;
this.update();},
isValid: function() {return true;},
isInRange: function() {return true;},
isEmpty: function() {return ( /^\s*$/.test(this.textbox.value) );},
isMissing: function() {return ( this.required && this.isEmpty() );},
update: function() {this.lastCheckedValue = this.textbox.value;
this.missingSpan.style.display = "none";
this.invalidSpan.style.display = "none";
this.rangeSpan.style.display = "none";
var empty = this.isEmpty();
var valid = true;
if(this.promptMessage != this.textbox.value){valid = this.isValid();}
var missing = this.isMissing();
if(missing){this.missingSpan.style.display = "";}else if( !empty && !valid ){this.invalidSpan.style.display = "";}else if( !empty && !this.isInRange() ){this.rangeSpan.style.display = "";}
this.highlight();},
updateClass: function(className){var pre = this.classPrefix;
dojo.html.removeClass(this.textbox,pre+"Empty");
dojo.html.removeClass(this.textbox,pre+"Valid");
dojo.html.removeClass(this.textbox,pre+"Invalid");
dojo.html.addClass(this.textbox,pre+className);},
highlight: function() {if (this.isEmpty()) {this.updateClass("Empty");}else if (this.isValid() && this.isInRange() ){this.updateClass("Valid");}else if(this.textbox.value != this.promptMessage){this.updateClass("Invalid");}else{this.updateClass("Empty");}},
onfocus: function(evt) {if ( !this.listenOnKeyPress) {this.updateClass("Empty");}},
onblur: function(evt) {this.filter();
this.update();},
onkeyup: function(evt){if(this.listenOnKeyPress){this.update();}else if (this.textbox.value != this.lastCheckedValue){this.updateClass("Empty");}},
postMixInProperties: function(localProperties, frag) {dojo.widget.ValidationTextbox.superclass.postMixInProperties.apply(this, arguments);
this.messages = dojo.i18n.getLocalization("dojo.widget", "validate", this.lang);
dojo.lang.forEach(["invalidMessage", "missingMessage", "rangeMessage"], function(prop) {if(this[prop]){ this.messages[prop] = this[prop]; }}, this);},
fillInTemplate: function() {dojo.widget.ValidationTextbox.superclass.fillInTemplate.apply(this, arguments);
this.textbox.isValid = function() { this.isValid.call(this); };
this.textbox.isMissing = function() { this.isMissing.call(this); };
this.textbox.isInRange = function() { this.isInRange.call(this); };
dojo.html.setClass(this.invalidSpan,this.invalidClass);
this.update();
this.filter();
if(dojo.render.html.ie){ dojo.html.addClass(this.domNode, "ie"); }
if(dojo.render.html.moz){ dojo.html.addClass(this.domNode, "moz"); }
if(dojo.render.html.opera){ dojo.html.addClass(this.domNode, "opera"); }
if(dojo.render.html.safari){ dojo.html.addClass(this.domNode, "safari"); }}}
);
