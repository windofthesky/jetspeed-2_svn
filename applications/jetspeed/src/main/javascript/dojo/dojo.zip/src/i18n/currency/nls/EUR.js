
({"displayName":"EUR","symbol":"€"})