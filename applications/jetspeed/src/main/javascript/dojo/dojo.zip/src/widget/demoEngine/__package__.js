
dojo.kwCompoundRequire({browser: [
"dojo.widget.demoEngine.DemoItem",
"dojo.widget.demoEngine.DemoNavigator",
"dojo.widget.demoEngine.DemoPane",
"dojo.widget.demoEngine.SourcePane",
"dojo.widget.demoEngine.DemoContainer"
]});
dojo.provide("dojo.widget.demoEngine.*");
