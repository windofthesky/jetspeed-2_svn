
({"displayName":"Italian Lira","symbol":"₤"})