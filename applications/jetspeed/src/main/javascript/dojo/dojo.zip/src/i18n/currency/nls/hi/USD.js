
({"displayName":"अमरीकी डालर","symbol":"$"})