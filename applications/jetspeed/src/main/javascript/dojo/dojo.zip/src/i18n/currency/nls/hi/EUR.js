
({"displayName":"य�?रो","symbol":"€"})