Directory: portal/src/webapp/WEB-INF/pages
Contents: custom portal PSML pages content
Usage: overrides default Jetspeed-2 pages content
