dj_deprecated("dojo.reflect is merged into dojo.lang (dojo.lang[type]).  Will be removed by 0.4");
dojo.hostenv.conditionalLoadModule({
	common: ["dojo.reflect.reflection"]
});
dojo.hostenv.moduleLoaded("dojo.reflect.*");
