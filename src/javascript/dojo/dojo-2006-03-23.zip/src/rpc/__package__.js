dojo.hostenv.conditionalLoadModule({
	common: ["dojo.rpc.JsonService", false, false]
});
dojo.hostenv.moduleLoaded("dojo.rpc.*");
