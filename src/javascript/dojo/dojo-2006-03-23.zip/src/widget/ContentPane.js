// This widget doesn't do anything; is basically the same as <div>.
// It's useful as a child of LayoutPane, SplitPane, or TabPane.
// But note that those classes can contain any widget as a child.

dojo.provide("dojo.widget.ContentPane");
dojo.requireAfterIf("html", "dojo.widget.html.ContentPane");
