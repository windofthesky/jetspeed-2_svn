dojo.hostenv.conditionalLoadModule({
	common: [
		"dojo.animation.AnimationEvent",
		"dojo.animation.Animation",
		"dojo.animation.AnimationSequence"
	]
});
dojo.hostenv.moduleLoaded("dojo.animation.*");
