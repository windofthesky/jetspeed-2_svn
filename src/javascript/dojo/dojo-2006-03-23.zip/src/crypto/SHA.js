dojo.provide("dojo.crypto.SHA");
dojo.require("dojo.crypto");

dojo.crypto.SHA = new function(){
	this.compute=function(s){
	};
}();
