dojo.provide("dojo.crypto.Rijndael");
dojo.require("dojo.crypto");

dojo.crypto.Rijndael = new function(){
	this.encrypt=function(plaintext, key){
	};
	this.decrypt=function(ciphertext, key){
	};
}();

dojo.crypto.AES = dojo.crypto.Rijndael;	//	alias
