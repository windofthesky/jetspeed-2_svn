
dojo.kwCompoundRequire({common: [ "dojo.html.common",
"dojo.html.style" ]});
dojo.provide("dojo.html.*");
