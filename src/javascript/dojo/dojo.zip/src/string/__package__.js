
dojo.kwCompoundRequire({common: [
"dojo.string",
"dojo.string.common",
"dojo.string.extras",
"dojo.string.Builder"
]});
dojo.provide("dojo.string.*");
