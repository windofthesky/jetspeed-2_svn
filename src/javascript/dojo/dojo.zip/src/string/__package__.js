dojo.hostenv.conditionalLoadModule({
	common: [
		"dojo.string",
		"dojo.string.common",
		"dojo.string.extras",
		"dojo.string.Builder"
	]
});
dojo.hostenv.moduleLoaded("dojo.string.*");
