dojo.provide("dojo.animation");
dojo.require("dojo.animation.Animation");
