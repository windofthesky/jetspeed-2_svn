dojo.provide("dojo.animation");
dojo.require("dojo.animation.Animation");

dojo.deprecated("dojo.animation is slated for removal in 0.5; use dojo.lfx instead.", "0.5");
