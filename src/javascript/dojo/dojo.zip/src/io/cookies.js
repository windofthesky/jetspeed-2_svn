dojo.deprecated("dojo.io.cookies has been replaced by dojo.io.cookie");
dojo.require("dojo.io.cookie");
if(!dojo.io.cookies) { dojo.io.cookies = dojo.io.cookie; }
dojo.provide("dojo.io.cookies");
