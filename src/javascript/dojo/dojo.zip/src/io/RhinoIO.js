dojo.provide("dojo.io.RhinoIO");

// TODO: this doesn't execute
/*dojo.io.SyncHTTPRequest = function(){
	dojo.io.SyncRequest.call(this);

	this.send = function(URI){
	}
}

dojo.inherits(dojo.io.SyncHTTPRequest, dojo.io.SyncRequest);
*/
