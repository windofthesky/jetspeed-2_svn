
;(function(){if(typeof dj_usingBootstrap != "undefined"){return;}
var isRhino = false;
var isSpidermonkey = false;
var isDashboard = false;
if((typeof this["load"] == "function")&&((typeof this["Packages"] == "function")||(typeof this["Packages"] == "object"))){isRhino = true;}else if(typeof this["load"] == "function"){isSpidermonkey  = true;}else if(window.widget){isDashboard = true;}
var tmps = [];
if((this["djConfig"])&&((djConfig["isDebug"])||(djConfig["debugAtAllCosts"]))){tmps.push("debug.js");}
if((this["djConfig"])&&(djConfig["debugAtAllCosts"])&&(!isRhino)&&(!isDashboard)){tmps.push("browser_debug.js");}
var loaderRoot = djConfig["baseScriptUri"];
if((this["djConfig"])&&(djConfig["baseLoaderUri"])){loaderRoot = djConfig["baseLoaderUri"];}
for(var x=0; x < tmps.length; x++){var spath = loaderRoot+"src/"+tmps[x];
if(isRhino||isSpidermonkey){load(spath);} else {try {document.write("<scr"+"ipt type='text/javascript' src='"+spath+"'></scr"+"ipt>");} catch (e) {var script = document.createElement("script");
script.src = spath;
document.getElementsByTagName("head")[0].appendChild(script);}}}})();
