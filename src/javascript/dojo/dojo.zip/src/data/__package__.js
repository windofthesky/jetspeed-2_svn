dojo.experimental("dojo.data.*");
dojo.kwCompoundRequire({
	common: [
		"dojo.data.Item",
		"dojo.data.ResultSet",
		"dojo.data.provider.FlatFile"
	]
});
dojo.hostenv.moduleLoaded("dojo.data.*");

