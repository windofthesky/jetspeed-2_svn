
dojo.provide("dojo.data.old.provider.JotSpot");
dojo.require("dojo.data.old.provider.Base");
dojo.data.old.provider.JotSpot = function() {dojo.unimplemented('dojo.data.old.provider.JotSpot');};
dojo.inherits(dojo.data.old.provider.JotSpot, dojo.data.old.provider.Base);
