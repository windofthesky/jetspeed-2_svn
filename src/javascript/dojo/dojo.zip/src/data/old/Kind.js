
dojo.provide("dojo.data.old.Kind");
dojo.require("dojo.data.old.Item");
dojo.data.old.Kind = function( dataProvider) {dojo.data.old.Item.call(this, dataProvider);};
dojo.inherits(dojo.data.old.Kind, dojo.data.old.Item);
