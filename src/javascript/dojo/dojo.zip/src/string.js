dojo.provide("dojo.string");
dojo.require("dojo.string.common");
