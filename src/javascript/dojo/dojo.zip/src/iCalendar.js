
dojo.require("dojo.cal.iCalendar");
dojo.deprecated("dojo.icalendar", "use dojo.cal.iCalendar isntead", "0.5");
