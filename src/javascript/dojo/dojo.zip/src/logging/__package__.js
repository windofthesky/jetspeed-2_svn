dojo.kwCompoundRequire({
	common: [["dojo.logging.Logger", false, false]],
	rhino: ["dojo.logging.RhinoLogger"]
});
dojo.provide("dojo.logging.*");
