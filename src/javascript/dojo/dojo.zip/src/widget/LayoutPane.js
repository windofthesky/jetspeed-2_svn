dojo.provide("dojo.widget.LayoutPane");

dojo.require("dojo.widget.*");
dojo.requireAfterIf("html", "dojo.widget.html.LayoutPane");
dojo.widget.tags.addParseTreeHandler("dojo:LayoutPane");

// NOTE: there's no stub file for this widget
