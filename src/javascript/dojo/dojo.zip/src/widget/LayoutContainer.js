dojo.provide("dojo.widget.LayoutContainer");

dojo.require("dojo.widget.*");
dojo.requireAfterIf("html", "dojo.widget.html.LayoutContainer");
dojo.widget.tags.addParseTreeHandler("dojo:LayoutContainer");

// NOTE: there's no stub file for this widget
