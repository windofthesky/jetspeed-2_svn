dojo.provide("dojo.widget.Checkbox");

dojo.requireAfterIf("html", "dojo.widget.html.Checkbox");
