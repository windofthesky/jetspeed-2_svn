dojo.provide("dojo.widget.Container");
dojo.requireAfterIf("html", "dojo.widget.html.Container");
