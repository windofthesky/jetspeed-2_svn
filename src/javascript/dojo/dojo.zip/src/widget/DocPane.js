dojo.provide("dojo.widget.DocPane");
dojo.requireAfterIf("html", "dojo.widget.html.DocPane");
