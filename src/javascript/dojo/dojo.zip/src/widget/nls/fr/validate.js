({
		invalidMessage: "* La valeur saisie est incorrecte.",
		missingMessage: "* Cette valeur est obligatoire.",
		rangeMessage: "* Cette valeur est hors limites."
})
