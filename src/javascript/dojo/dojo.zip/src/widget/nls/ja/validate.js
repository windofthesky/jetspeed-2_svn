/*<?xml version="1.0" encoding="UTF-8" ?>*/
({
		invalidMessage: "* 入力したデータに該当するものがありません。",
		missingMessage: "* 入力が必須です。",
		rangeMessage: "* 入力した数値は選択範囲外です。"
})
