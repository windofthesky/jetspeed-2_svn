// this is a stub that will be removed in 0.4, see ../Button2.html for details

dojo.provide("dojo.widget.html.Button2");

dojo.widget.html.Button2 = function(){}
dojo.inherits(dojo.widget.html.Button2, dojo.widget.html.Button);
dojo.lang.extend(dojo.widget.html.Button2, { widgetType: "Button2" });

dojo.widget.html.DropDownButton2 = function(){}
dojo.inherits(dojo.widget.html.DropDownButton2, dojo.widget.html.DropDownButton);
dojo.lang.extend(dojo.widget.html.DropDownButton2, { widgetType: "DropDownButton2" });

dojo.widget.html.ComboButton2 = function(){}
dojo.inherits(dojo.widget.html.ComboButton2, dojo.widget.html.ComboButton);
dojo.lang.extend(dojo.widget.html.ComboButton2, { widgetType: "ComboButton2" });