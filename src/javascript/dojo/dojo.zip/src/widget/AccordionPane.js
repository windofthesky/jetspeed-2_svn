dojo.provide("dojo.widget.AccordionPane");
dojo.requireAfterIf("html", "dojo.widget.html.AccordionPane");
