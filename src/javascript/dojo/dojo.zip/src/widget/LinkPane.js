dojo.provide("dojo.widget.LinkPane");

dojo.require("dojo.widget.*");
dojo.requireAfterIf("html", "dojo.widget.html.LinkPane");
dojo.widget.tags.addParseTreeHandler("dojo:LinkPane");

// NOTE: there's no stub file for this widget
