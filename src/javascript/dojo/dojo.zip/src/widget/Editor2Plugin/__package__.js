dojo.kwCompoundRequire({
	common: [ "dojo.widget.Editor2", 
			 "dojo.widget.Editor2Toolbar"]
});
dojo.provide("dojo.widget.Editor2Plugin.*");
