dojo.provide("dojo.widget.TitlePane");
dojo.requireAfterIf("html", "dojo.widget.html.TitlePane");
