dojo.provide("dojo.widget.Tooltip");
dojo.require("dojo.widget.Widget");

dojo.requireAfterIf("html", "dojo.widget.html.Tooltip");
