dojo.hostenv.conditionalLoadModule({
	common: ["dojo.uri.Uri", false, false]
});
dojo.hostenv.moduleLoaded("dojo.uri.*");
