dojo.hostenv.conditionalLoadModule({
	common: [
		"dojo.crypto",
		"dojo.crypto.MD5"
	]
});
dojo.hostenv.moduleLoaded("dojo.crypto.*");
