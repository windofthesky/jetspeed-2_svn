dojo.provide("dojo.crypto.SHA256");
dojo.require("dojo.crypto");

dojo.crypto.SHA256 = new function(){
	this.compute=function(s){
	};
}();
