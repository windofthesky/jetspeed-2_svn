dojo.provide("dojo.crypto.SHA256");
dojo.require("dojo.crypto");
dojo.require("dojo.experimental");

dojo.experimental("dojo.crypto.SHA256");

dojo.crypto.SHA256 = new function(){
	this.compute=function(s){
	};
}();
