dojo.provide("dojo.crypto.SHA256");
dojo.require("dojo.crypto");

dojo.experimental("dojo.crypto.SHA256");

dojo.crypto.SHA256 = new function(){
	this.compute=function(s){
	};
}();
