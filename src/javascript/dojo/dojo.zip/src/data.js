dojo.provide("dojo.data");

// currently a stub for dojo.data

dojo.data = {};
