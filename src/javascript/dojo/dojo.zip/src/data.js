
dojo.provide("dojo.data");
dojo.data = {};
