dojo.require("dojo.lang");
dj_deprecated("dojo.lang.Lang is deprecated, use dojo.lang instead");
