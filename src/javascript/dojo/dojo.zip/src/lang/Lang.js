dojo.require("dojo.lang");
dojo.deprecated("dojo.lang.Lang", "use dojo.lang instead", "0.4");
