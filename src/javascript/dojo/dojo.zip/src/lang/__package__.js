dojo.hostenv.conditionalLoadModule({
	common: [
		"dojo.lang",
		"dojo.lang.common",
		"dojo.lang.assert",
		"dojo.lang.array",
		"dojo.lang.type",
		"dojo.lang.func",
		"dojo.lang.extras",
		"dojo.lang.repr"
	]
});
dojo.hostenv.moduleLoaded("dojo.lang.*");
