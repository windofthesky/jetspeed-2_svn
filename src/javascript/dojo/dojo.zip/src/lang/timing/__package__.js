dojo.provide("dojo.lang.timing.*");
