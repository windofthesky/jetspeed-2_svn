dojo.hostenv.conditionalLoadModule({
	common: [
		"dojo.text.String",
		"dojo.text.Builder"
	]
});
dojo.hostenv.moduleLoaded("dojo.text.*");
