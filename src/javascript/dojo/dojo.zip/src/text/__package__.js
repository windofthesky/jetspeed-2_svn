dojo.kwCompoundRequire({
	common: [
		"dojo.text.String",
		"dojo.text.Builder"
	]
});
dojo.provide("dojo.text.*");
