
dojo.kwCompoundRequire({common: [
"dojo.text.String",
"dojo.text.Builder"
]});
dojo.deprecated("dojo.text", "textDirectory moved to cal, text.String and text.Builder havne't been here for awhile", "0.5");
