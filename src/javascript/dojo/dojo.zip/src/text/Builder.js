dojo.provide("dojo.text.Builder");
dojo.require("dojo.string.Builder");

dojo.deprecated("dojo.text.Builder", "use dojo.string.Builder instead", "0.4");

dojo.text.Builder = dojo.string.Builder;
