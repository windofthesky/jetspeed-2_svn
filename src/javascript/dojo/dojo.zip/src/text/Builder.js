dojo.provide("dojo.text.Builder");
dojo.require("dojo.string.Builder");

dojo.deprecated("dojo.text.Builder is deprecated, use dojo.string.Builder instead");

dojo.text.Builder = dojo.string.Builder;
