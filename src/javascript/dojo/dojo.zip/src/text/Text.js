dojo.deprecated("dojo.text.Text", "replaced by dojo.string", "0.4");
dojo.require("dojo.string");

dojo.text = dojo.string;
dojo.provide("dojo.text.Text");
