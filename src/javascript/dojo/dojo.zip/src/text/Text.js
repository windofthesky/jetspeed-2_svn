dj_deprecated("dojo.text.Text is being replaced by dojo.string");
dojo.require("dojo.string");

dojo.text = dojo.string;
dojo.provide("dojo.text.Text");
