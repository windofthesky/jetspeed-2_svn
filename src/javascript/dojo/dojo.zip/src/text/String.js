dojo.deprecated("dojo.text.String", "replaced by dojo.string", "0.4");
dojo.require("dojo.string");

dojo.text = dojo.string;
dojo.provide("dojo.text.String");
