dojo.require("dojo.cal.textDirectory");
dojo.deprecate("dojo.text.textDirectory", "use dojo.cal.textDirectory", "0.5");
