dojo.deprecated("dojo.math.Math", "include dojo.math instead", "0.4");
dojo.require("dojo.math");
