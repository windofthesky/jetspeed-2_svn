dojo.deprecated("dojo.math.Math does not exist, include dojo.math");
dojo.require("dojo.math");
