dojo.require("dojo.xml.Parse");
dojo.kwCompoundRequire({
	common:		["dojo.xml.domUtil"],
    browser: 	["dojo.xml.htmlUtil"],
    dashboard: 	["dojo.xml.htmlUtil"],
    svg: 		["dojo.xml.svgUtil"]
});
dojo.provide("dojo.xml.*");
