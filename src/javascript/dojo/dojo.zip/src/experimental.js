
dojo.provide("dojo.experimental");
dojo.experimental = function( moduleName,  extra){var message = "EXPERIMENTAL: " + moduleName;
message += " -- Not yet ready for use.  APIs subject to change without notice.";
if(extra){ message += " " + extra; }
dojo.debug(message);}
