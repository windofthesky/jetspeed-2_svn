dojo.provide("dojo.style");
dojo.kwCompoundRequire({
	browser: ["dojo.html.style"]
});
dojo.deprecated("dojo.style", "replaced by dojo.html.style", "0.5");
