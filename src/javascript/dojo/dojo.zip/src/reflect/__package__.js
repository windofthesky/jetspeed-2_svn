dojo.deprecated("dojo.reflect is merged into dojo.lang (dojo.lang[type]).  Will be removed by 0.4");
dojo.kwCompoundRequire({
	common: ["dojo.reflect.reflection"]
});
dojo.provide("dojo.reflect.*");
