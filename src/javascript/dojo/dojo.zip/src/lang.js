
dojo.provide("dojo.lang");
dojo.require("dojo.lang.common");
dojo.deprecated("dojo.lang", "replaced by dojo.lang.common", "0.5");
