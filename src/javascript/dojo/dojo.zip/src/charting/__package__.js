dojo.provide("dojo.charting.*");
