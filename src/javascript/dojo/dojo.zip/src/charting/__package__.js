
dojo.provide("dojo.charting.*");
