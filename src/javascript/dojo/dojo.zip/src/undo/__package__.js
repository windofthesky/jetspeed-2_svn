
dojo.require("dojo.undo.Manager");
dojo.provide("dojo.undo.*");
