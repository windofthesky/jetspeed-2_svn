dojo.provide("dojo.collections.ByteArray");
dojo.require("dojo.collections.Collections");

//	the following is an implementation of a 32 bit Byte Array.
dojo.collections.ByteArray = function(s){



}
