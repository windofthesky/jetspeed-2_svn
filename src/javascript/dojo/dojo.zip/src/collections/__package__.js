
dojo.kwCompoundRequire({common: [
"dojo.collections.Collections",
"dojo.collections.SortedList",
"dojo.collections.Dictionary",
"dojo.collections.Queue",
"dojo.collections.ArrayList",
"dojo.collections.Stack",
"dojo.collections.Set"
]});
dojo.provide("dojo.collections.*");
