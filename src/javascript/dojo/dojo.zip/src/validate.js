
dojo.provide("dojo.validate");
dojo.require("dojo.validate.common");
