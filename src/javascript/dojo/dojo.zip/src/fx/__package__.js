dojo.hostenv.conditionalLoadModule({
	browser: ["dojo.fx.html"],
	dashboard: ["dojo.fx.html"]
});
dojo.hostenv.moduleLoaded("dojo.fx.*");
