dojo.kwCompoundRequire({
	browser: ["dojo.fx.html"],
	dashboard: ["dojo.fx.html"]
});
dojo.provide("dojo.fx.*");
