dojo.hostenv.conditionalLoadModule({
	browser:	["dojo.graphics.htmlEffects"],
	dashboard:	["dojo.graphics.htmlEffects"]
});
dojo.hostenv.moduleLoaded("dojo.graphics.*");
