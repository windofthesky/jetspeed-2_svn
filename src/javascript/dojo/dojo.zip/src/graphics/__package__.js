dojo.kwCompoundRequire({
	browser:	["dojo.graphics.htmlEffects"],
	dashboard:	["dojo.graphics.htmlEffects"]
});
dojo.provide("dojo.graphics.*");
