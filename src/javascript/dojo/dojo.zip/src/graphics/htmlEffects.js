dojo.provide("dojo.graphics.htmlEffects");
dojo.require("dojo.fx.*");

dj_deprecated("dojo.graphics.htmlEffects is deprecated, use dojo.fx.html instead");

dojo.graphics.htmlEffects = dojo.fx.html;
