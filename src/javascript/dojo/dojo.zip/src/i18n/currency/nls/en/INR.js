({
	displayName: "Indian Rupee"
})