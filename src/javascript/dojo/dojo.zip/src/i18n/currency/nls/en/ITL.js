({
	displayName: "Italian Lira"
})