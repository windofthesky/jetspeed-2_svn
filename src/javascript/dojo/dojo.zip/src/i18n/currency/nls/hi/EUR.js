({
	displayName: "युरो"
})