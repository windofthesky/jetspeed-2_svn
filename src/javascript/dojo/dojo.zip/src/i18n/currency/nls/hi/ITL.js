
({"displayName":"इतली का लीरा","symbol":"₤"})