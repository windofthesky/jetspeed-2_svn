
({"displayName":"Japanese Yen","symbol":"¥"})