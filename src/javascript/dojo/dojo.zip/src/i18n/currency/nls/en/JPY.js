({
	displayName: "Japanese Yen"
})