({
	displayName: "JPY",
	symbol: "\u00a5"
})