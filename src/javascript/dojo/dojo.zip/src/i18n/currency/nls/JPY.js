
({"displayName":"JPY","symbol":"¥"})