({
	displayName: "米ドル"
})