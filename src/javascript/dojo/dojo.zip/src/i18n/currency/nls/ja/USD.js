
({"displayName":"米ドル","symbol":"$"})