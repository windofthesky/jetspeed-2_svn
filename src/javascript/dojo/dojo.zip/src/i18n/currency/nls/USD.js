
({"displayName":"USD","symbol":"$"})