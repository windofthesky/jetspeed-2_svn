({
	displayName: "USD",
	symbol: "$"
})