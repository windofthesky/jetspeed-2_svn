({
	displayName: "ユーロ"
})