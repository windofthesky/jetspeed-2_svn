
({"displayName":"ユーロ","symbol":"€"})