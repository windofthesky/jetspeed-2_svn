
({"displayName":"英国�?ンド","symbol":"£"})