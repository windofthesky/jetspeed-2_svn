({
	displayName: "英国ポンド"
})