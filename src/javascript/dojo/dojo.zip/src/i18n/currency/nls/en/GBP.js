({
	displayName: "British Pound Sterling"
})