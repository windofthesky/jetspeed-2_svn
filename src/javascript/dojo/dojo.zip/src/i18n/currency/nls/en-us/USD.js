({
	symbol: "$"
})