
({"symbol":"$","displayName":"US Dollar"})