({
	displayName: "イタリア リラ"
})