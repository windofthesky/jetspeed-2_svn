
({"displayName":"イタリア リラ","symbol":"₤"})