
({"displayName":"जापानी येन","symbol":"¥"})