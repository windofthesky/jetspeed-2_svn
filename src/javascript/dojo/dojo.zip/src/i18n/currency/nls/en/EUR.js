
({"displayName":"Euro","symbol":"€"})