({
	displayName: "Euro"
})