
({"displayName":"GBP","symbol":"£"})