({
	displayName: "GBP",
	symbol: "\u00A3"
})