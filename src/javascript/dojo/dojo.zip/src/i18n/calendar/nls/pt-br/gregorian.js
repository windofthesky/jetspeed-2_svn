({
	'dateFormat-medium': "dd/MM/yyyy",
	'dateFormat-short': "dd/MM/yy",

	'timeFormat-full': "HH'h'mm'min'ss's' z",
	'timeFormat-long': "H'h'm'min's's' z"
})