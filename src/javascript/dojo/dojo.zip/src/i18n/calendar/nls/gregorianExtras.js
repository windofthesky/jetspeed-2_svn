// Dojo-specific extensions to the CLDR
({
	'dateFormat-yearOnly': "yyyy"
})