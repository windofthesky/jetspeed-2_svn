
dojo.provide("dojo.date");
dojo.deprecated("dojo.date", "use one of the modules in dojo.date.* instead", "0.5");
