dojo.provide("dojo.html");

dojo.require("dojo.html.*");
dojo.deprecated("dojo.html", "replaced by dojo.html.*", "0.5");
