
dojo.kwCompoundRequire({common: ["dojo.dnd.DragAndDrop"],
browser: ["dojo.dnd.HtmlDragAndDrop"],
dashboard: ["dojo.dnd.HtmlDragAndDrop"]});
dojo.provide("dojo.dnd.*");
